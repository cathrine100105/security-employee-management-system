package com.security.management.repository;

import com.security.management.entity.SecurityEntity;
import com.security.management.model.FilterDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SecurityRepository extends JpaRepository<SecurityEntity,Long> {
    SecurityEntity findByGuardId(long guardId);


    @Query("""
SELECT s FROM SecurityEntity s
WHERE (:name IS NULL OR LOWER(s.name)
LIKE LOWER(CONCAT('%', :name, '%')))
AND (:shiftType IS NULL OR s.shiftType = :shiftType)
AND (:qualification IS NULL OR s.qualification = :qualification)
AND (:assignedLocation IS NULL OR LOWER(s.assignedLocation)
LIKE LOWER(CONCAT('%', :assignedLocation, '%')))
AND (:status IS NULL OR s.status = :status)
""")
    List<SecurityEntity> search(
            @Param("name") String name,
            @Param("shiftType") String shiftType,
            @Param("qualification") String qualification,
            @Param("assignedLocation") String assignedLocation,
            @Param("status") FilterDTO.StatusEnum status
    );

    Page<SecurityEntity> findAll(Pageable pageable);
}
